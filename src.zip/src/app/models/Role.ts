export class Role {
  roleName: string = '';
}
