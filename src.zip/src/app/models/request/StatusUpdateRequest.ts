export class StatusUpdateRequest {
  id: number = 0;
  status: string = '';
}
