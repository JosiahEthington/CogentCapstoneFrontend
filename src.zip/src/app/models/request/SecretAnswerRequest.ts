export class SecretAnswerRequest {
  answer: string = '';
}
