export class SignUpRequest {
  username: string = '';
  password: string = '';
  fullname: string = '';
}
