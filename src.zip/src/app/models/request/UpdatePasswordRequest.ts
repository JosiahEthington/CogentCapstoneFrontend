export class UpdatePasswordRequest {
  newPassword: string = '';
}
