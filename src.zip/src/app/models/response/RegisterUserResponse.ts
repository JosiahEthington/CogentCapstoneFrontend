export class RegisterUserResponse {
  id: number = 0;
  username: string = '';
  fullname: string = '';
  password: string = '';
}
