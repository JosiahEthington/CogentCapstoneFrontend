export class UpdateCustomerResponse {
  customerId: number = 0;
  fullname: string = '';
  phone: string = '';
  pan: string = '';
  aadhar: string = '';
  secretQuestion: string = '';
  secretAnswer: string = '';
  panImage: string = '';
  aadharImage: string = '';
}
