export class StaffSummaryResponse {
  staffId: number = 0;
  staffName: string = '';
  status: string = '';
}
