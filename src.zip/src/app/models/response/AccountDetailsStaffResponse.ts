export class AccountDetailsStaffResponse {
  accountNumber: number = 0;
  customerName: string = '';
  balance: number = 0;
  transactions: any = {};
}
