import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-staff-adjust-account',
  templateUrl: './staff-adjust-account.component.html',
  styleUrls: ['./staff-adjust-account.component.css']
})
export class StaffAdjustAccountComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
