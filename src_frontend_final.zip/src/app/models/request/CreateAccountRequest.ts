export class CreateAccountRequest {
  accountType: string = '';
  accountBalance: number = 0;
  approved: string = '';
}
