export class AddBeneficiaryRequest {
  accountNumber: number = 0;
  accountType: string = '';
  approved: string = 'no';
  name: string = '';
}
