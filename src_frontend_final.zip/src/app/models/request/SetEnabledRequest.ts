export class SetEnabledRequest {
  id: number = 0;
  status: boolean = false;
}
