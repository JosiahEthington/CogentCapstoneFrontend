export class UpdateCustomerRequest {
  fullname: string = '';
  phone: string = '';
  pan: string = '';
  aadhar: string = '';
  secretQuestion: string = '';
  secretAnswer: string = '';
  panImage: string = '';
  aadharImage: string = '';
}
