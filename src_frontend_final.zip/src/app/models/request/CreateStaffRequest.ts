export class CreateStaffRequest {
  staffFullName: string = '';
  staffUserName: string = '';
  staffPassword: string = '';
}
