export class ApproveAccountRequest {
  accountNumber: number = 0;
  approved: string = 'yes';
}
