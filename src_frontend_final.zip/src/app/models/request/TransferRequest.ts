export class TransferRequest {
  fromAccount: number = 0;
  toAccount: number = 0;
  amount: number = 0;
  reason: string = '';
  customerId: number = 0;
}
