export class TransferRequestStaff {
  fromAccount: number = 0;
  toAccount: number = 0;
  amount: number = 0;
  reason: string = '';
  byStaff: string = '';
}
