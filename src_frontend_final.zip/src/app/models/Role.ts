export class Role {
  roleName: string = '';
  constructor(roleName: string) {
    this.roleName = roleName;
  }
}
