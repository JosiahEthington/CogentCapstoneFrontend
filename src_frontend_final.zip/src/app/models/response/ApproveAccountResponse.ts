export class ApproveAccountResponse {
  accountNumber: number = 0;
  approval: string = 'yes';
}
