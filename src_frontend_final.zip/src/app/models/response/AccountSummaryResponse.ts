export class AccountSummaryResponse {
  accountNumber: number = 0;
  accountType: string = '';
  balance: number = 0;
  status: string = '';
}
