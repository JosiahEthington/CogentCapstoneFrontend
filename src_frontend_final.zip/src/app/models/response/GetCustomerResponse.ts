export class GetCustomerResponse {
  username: string = '';
  fullName: string = '';
  phone: string = '';
  pan: string = '';
  aadhar: string = '';
}
