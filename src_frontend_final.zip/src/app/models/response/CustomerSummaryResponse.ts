export class CustomerSummaryResponse {
  customerId: number = 0;
  customerName: string = '';
  status: string = '';
  created: Date = new Date();
}
