export class BeneficiarySummaryResponse {
  beneficiaryId: number = 0;
  beneficiaryAccountNo: number = 0;
  beneficiaryName: string = '';
  active: string = '';
}
